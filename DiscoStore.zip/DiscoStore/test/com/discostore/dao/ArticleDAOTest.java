package com.discostore.dao;

import static org.junit.Assert.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityNotFoundException;
import javax.persistence.Persistence;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.discostore.entity.Article;
import com.discostore.entity.Auteur;
import com.discostore.entity.Format;
import com.discostore.entity.Genre;

public class ArticleDAOTest   {
    private static ArticleDAO articleDAO;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        articleDAO = new ArticleDAO( );
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
        articleDAO.close();
    }



    @Test
    public void testCreateArticle() throws IOException {
        
        Article newArticle = new Article();
        
        Genre genre = new Genre("Rock");
        genre.setCodGenre( 1 );
        newArticle.setGenre( genre );
        
        Auteur auteur = new Auteur("Animal Collective");
        auteur.setCodAuteur( 1 );
        newArticle.setAuteur( auteur );
        
        Format format = new Format("ep");
        format.setCodFormat( 2 );
        newArticle.setFormat( format );    
        
        newArticle.setStock( 10 );
        newArticle.setPrix( (float) 24.95 );
        newArticle.setTitre( "untitled ep" );
        
        
        String imagePath = "C:\\Users\\JG\\Desktop\\platine.jpg";
        
        byte[] imageBytes = Files.readAllBytes(Paths.get(imagePath));
        newArticle.setImg( imageBytes );
        
       
        
        
        Article createdArticle = articleDAO.create( newArticle );

        assertTrue(createdArticle.getRefArticle()>0);
    }

    
    @Test
    public void testUpdateArticle() throws IOException {
        
        Article existArticle = new Article();
        existArticle.setRefArticle( 187 );
        Genre genre = new Genre("Post-Rock");
        genre.setCodGenre( 2 );
        existArticle.setGenre( genre );
        
        Auteur auteur = new Auteur("Bark Psychosis");
        auteur.setCodAuteur( 2 );
        existArticle.setAuteur( auteur );
        
        Format format = new Format("lp");
        format.setCodFormat( 1);
        existArticle.setFormat( format );    
        
        existArticle.setStock( 30 );
        existArticle.setPrix( 17.5f );
        existArticle.setTitre( "lp + ep" );
        
        
        String imagePath = "C:\\Users\\JG\\Desktop\\platine.jpg";
        
        byte[] imageBytes = Files.readAllBytes(Paths.get(imagePath));
        existArticle.setImg( imageBytes );
        
       
        
        
        Article updatedArticle = articleDAO.update( existArticle );

        assertEquals(updatedArticle.getTitre(), "lp + ep");
    }
    
    @Test(expected=EntityNotFoundException.class)
    public void testDeleteArticleFail() {      
        Integer articleId = 800;
        articleDAO.delete(articleId);       
        
    }
    
    @Test
    public void testDeleteArticleSuccess() {      
        Integer articleId = 187;
        articleDAO.delete(articleId);       
        assertTrue(true);  
    }

    
    @Test
    public void testGetArticleFail() {      
        Integer articleId = 187;
        Article articleSearched = articleDAO.get(articleId);
        assertNull(articleSearched);        
    }
    
    @Test
    public void testGetArticleSuccess() {      
        Integer articleId = 1;
        Article articleSearched = articleDAO.get(articleId);
        assertNotNull(articleSearched);        
    }

    @Test
    public void testListAll() {
        List<Article> listArticles = articleDAO.listAll();
        
        for (Article unArticle : listArticles) {
            System.out.println(unArticle.getTitre() + " - " + unArticle.getAuteur().getNomAuteur()); 
        }
        
        assertFalse(listArticles.isEmpty());
    } 
    
    @Test
    public void testFindByTitleNotExist() {
        String title = "java";
        Article article = articleDAO.findByTitle(title);
        
        assertNull(article);
    }
    
    
    
    @Test
    public void testFindByTitleExist() {
        String title = "Painting with";
        Article article = articleDAO.findByTitle(title);
        
        System.out.println(article.getAuteur().getNomAuteur());
        System.out.println(article.getPrix());
        
        assertNotNull(article);
        
    }
    
    @Test
    public void testCount() {
        long totalArticles = articleDAO.count();
        
        assertEquals(185, totalArticles);
    }
    
    
    
    
    @Test
    public void testListByGenre() {
        
        int genreId = 1;
       
        List<Article> listArticles = articleDAO.listByGenre( genreId );
        
        assertTrue(listArticles.size()>0);
    }
    
    
    
}
