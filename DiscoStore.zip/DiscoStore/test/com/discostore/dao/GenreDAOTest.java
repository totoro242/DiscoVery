package com.discostore.dao;

import static org.junit.Assert.*;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.discostore.entity.Admin;
import com.discostore.entity.Genre;

public class GenreDAOTest {

    private static GenreDAO genreDAO;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        
        genreDAO = new GenreDAO();
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
        genreDAO.close();
    }

    @Test
    public void testCreateGenre() {

        Genre newGenre = new Genre();
        newGenre.setIntituleGenre( "groovy" );

        Genre genre = genreDAO.create( newGenre );

        assertTrue( genre != null && genre.getCodGenre() > 0 );
    }

    @Test
    public void testUpdateGenre() {
        Genre genre = new Genre( "Java Core" );
        genre.setCodGenre( 18 );

        Genre genre2 = genreDAO.update( genre );

        assertEquals( genre.getIntituleGenre(), genre2.getIntituleGenre() );
    }

    @Test
    public void testGet() {
        Integer genreId = 18;
        Genre genre = genreDAO.get( genreId );

        assertNotNull( genre );
    }

    @Test
    public void testDeleteObject() {
        Integer genreID = 18;
        genreDAO.delete( genreID );

        Genre genre = genreDAO.get( genreID );

        assertNull( genre );
    }

    @Test
    public void testListAll() {
        List<Genre> listGenres = genreDAO.listAll();

        listGenres.forEach( c -> System.out.println( c.getIntituleGenre() + ", " ) );

        assertTrue( listGenres.size() > 0 );
    }

    @Test
    public void testCount() {
        long totalGenres = genreDAO.count();
        
        assertEquals(17, totalGenres);
    }
    
    @Test
    public void testFindByName() {
        
        String nomGenre="Rock";
        
        
        assertNotNull( genreDAO.findByName( nomGenre ) );
    }

}
