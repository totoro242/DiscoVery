package com.discostore.dao;

import static org.junit.Assert.*;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import com.discostore.entity.Admin;

public class AdminDAOTest{
    private static AdminDAO             adminDAO;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        
        adminDAO = new AdminDAO();      
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {

        adminDAO.close();
    }

    @Test
    public void testCreateAdmin() {
        Admin admin1 = new Admin();
        admin1.setMdpAdmin( "creeated" );
        admin1.setStatutAdmin( "creeated" );
        admin1 = adminDAO.create( admin1 );

        assertTrue( admin1.getIdAdmin() > 0 );
    }

    @Test
    public void testUpdateAdmin() {
        Admin admin1 = new Admin();
        admin1.setIdAdmin( 23 );
        admin1.setMdpAdmin( "11111" );
        admin1.setStatutAdmin( "vvvv" );

        admin1 = adminDAO.update( admin1 );
        String expected = "11111";
        String actual = admin1.getMdpAdmin();
        assertEquals( expected, actual );
    }

    @Test
    public void testSiAdminPresent() {
        Integer adminId = 1;
        Admin admin = adminDAO.get( adminId );
        if ( admin != null ) {
            System.out.println( "infos: " + admin.getMdpAdmin() + " " + admin.getStatutAdmin() );

        }
        assertNotNull( admin );
    }

    @Test
    public void testDelete() {
        Integer adminIdtoDelete = 22;
        adminDAO.delete( adminIdtoDelete );
        Admin admin = adminDAO.get( adminIdtoDelete );
        
        assertNull( admin );
        
    }

    @Test
    public void testListAll() {
        List<Admin> listAdmins = adminDAO.listAll();
        
        for (Admin admin : listAdmins) {
            System.out.println("infos : "+admin.getMdpAdmin()+" "+admin.getIdAdmin()+" "+admin.getStatutAdmin());
        }
        assertTrue( listAdmins.size() >0 );
    }
    
    @Test
    public void testCount() {
        long totalAdmins = adminDAO.count();
        //On veut s'assurer qu'il n'y a que 3 admins par exemple 
        assertEquals( 3, totalAdmins );
    }
    
    
    @Test
    public void testCheckLoginSuccess() {
        String email ="qwerty@outlook.com";
        String password = "qwerty";
        boolean isValidLogin = adminDAO.checkLogin( email, password );
        
        assertTrue(isValidLogin);
    }
    
    @Test
    public void testFindByEmail() {
        String email ="qwerty@outlook.com";
        Admin admin = adminDAO.findByEmail( email );
        
        assertNotNull(admin);
    }
    

}
