package com.discostore.dao;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.discostore.entity.Client;

public class ClientDAOTest {
    private static ClientDAO clientDAO;
    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        clientDAO = new ClientDAO();
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
        clientDAO.close();
    }

    @Test
    public void testCreateClient() {
        Client client = new Client();
        client.setNomCli( "McDonald" );
        client.setPrenomCli( "Bob" );
        client.setAddressLine1( "1 rue de la Liberté" );
        client.setAddressLine1( "Villa des Rosiers" );
        client.setMail( "bob@yahoo.fr" );
        client.setCp("06000");
        client.setVille("Nice");
        client.setPays("France");
        client.setPhone("06 12 13 14 15");
        client.setMdpCli("bombob");
        Client createdClient = clientDAO.create( client );
        assertTrue(createdClient.getNumCli()>0);
    }

    @Test
    public void testGet() {
        Integer clientID = 1;
        Client client = clientDAO.get( clientID );
        assertNotNull(client);
    }
    @Test
    public void testUpdateClient() {
        Client client =  clientDAO.get( 127 );
        client.setNomCli( "BigBob" );
        Client clientUpdated = clientDAO.update( client );
        assertTrue(clientUpdated.getNomCli().equals( "BigBob" ));
    }
    @Test
    public void testDeleteObject() {
        Integer clientID = 127;
        clientDAO.delete(clientID);
        Client client = clientDAO.get(127);
        
        assertNull(client);   
    }
    @Test
    public void testListAll() {
        List<Client> listClients = clientDAO.listAll();
        
        for (Client client : listClients) {
            System.out.println(client.getNomCli());
        }
        
        assertFalse(listClients.isEmpty());
    }
    @Test
    public void testCount() {
        long totalClients = clientDAO.count();
        
        assertEquals(122, totalClients);
        
    }
    @Test
    public void testFindByEmail() {
        String email ="eau.ultrices.sit@mauris.org";
        Client client = clientDAO.findByEmail( email );
        assertNotNull(client);
    }
    
    
    @Test
    public void testLoginOK() {
        String email ="eu.ultrices.sit@mauris.org";
        String password ="SCHMITT";
        Client client = clientDAO.checkLogin( email, password );
        assertNotNull(client);
    }
    
}
