package com.discostore.entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.discostore.entity.Admin;

public class AdminTest {

    public static void main( String[] args ) {
        Admin admin1 = new Admin();
        admin1.setMdpAdmin( "AAA" );
        admin1.setStatutAdmin( "tAAAsst" );
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory( "DiscoStore" );//avec le nom spécifié dans le persistence.xml
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        
        entityManager.getTransaction().begin();
        
        entityManager.persist( admin1 );
        
        entityManager.getTransaction().commit();
        
        entityManager.close();
        entityManagerFactory.close();
        System.out.println( "An admin object was persisted" );
        
    }

}
