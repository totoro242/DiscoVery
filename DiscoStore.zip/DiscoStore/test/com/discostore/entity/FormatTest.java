package com.discostore.entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.discostore.entity.Format;

public class FormatTest {

    public static void main( String[] args ) {
        Format format = new Format();
        format.setDescriptionFormat( "new ooone" );

        
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory( "DiscoStore" );//avec le nom spécifié dans le persistence.xml
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        
        entityManager.getTransaction().begin();
        
        entityManager.persist( format );
        
        entityManager.getTransaction().commit();
        
        entityManager.close();
        entityManagerFactory.close();
        System.out.println( "A format object was persisted" );
        
    }

}
