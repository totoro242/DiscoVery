package com.discostore.controller.frontend.client;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.discostore.service.ClientServices;

@WebServlet("/login")
public class ClientLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ClientLoginServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    
	    ClientServices clientServices = new ClientServices(request, response);
	    clientServices.showLogin();
	    
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    ClientServices clientServices = new ClientServices(request, response);
        clientServices.doLogin();
	}

}
