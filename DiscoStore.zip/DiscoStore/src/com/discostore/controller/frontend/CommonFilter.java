package com.discostore.controller.frontend;

import java.io.IOException;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

import com.discostore.dao.AuteurDAO;
import com.discostore.dao.GenreDAO;
import com.discostore.entity.Genre;
import com.discostore.entity.Auteur;
/*
 * Filtre pour afficher la liste des genres et des auteurs
 * sur toutes les pages du Frontend
 */
@WebFilter("/*")
public class CommonFilter implements Filter {
    private final GenreDAO genreDAO;
    private final AuteurDAO auteurDAO;
    public CommonFilter() {
        genreDAO = new GenreDAO();
        auteurDAO = new AuteurDAO();
    }

	public void destroy() {

	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
	    /**
	     * Pour limiter l'obtention de la liste des genres et des auteurs aux pages
	     * du Frontend, on récupère le chemin de la requète
	     */
	    
	    HttpServletRequest httpRequest = (HttpServletRequest)request;
	    String path = httpRequest.getRequestURI().substring( httpRequest.getContextPath().length() );
	    if (!path.startsWith("/admin/")) {
    	    List<Genre> ListGenres = genreDAO.listAll();
            request.setAttribute( "ListGenres", ListGenres );
            
            List<Auteur> ListAuteurs = auteurDAO.listAll();
            request.setAttribute( "ListAuteurs", ListAuteurs );
            
    	    //System.out.println( "CommonFilter->doFilter" );
 
	    }
	    chain.doFilter(request, response);
	}

	public void init(FilterConfig fConfig) throws ServletException {
		
	}

}
