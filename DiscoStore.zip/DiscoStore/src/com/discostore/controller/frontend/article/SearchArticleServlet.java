package com.discostore.controller.frontend.article;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.discostore.service.ArticleServices;

@WebServlet("/search")
public class SearchArticleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public SearchArticleServlet() {
      
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			//String keyword = request.getParameter( "keyword" );
			ArticleServices articleServices = new ArticleServices(  request, response );
			articleServices.search();
	}

}
