package com.discostore.controller.frontend.article;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.discostore.entity.Article;
import com.discostore.service.ArticleServices;
import com.discostore.dao.ArticleDAO;

@WebServlet("/view_article")
public class ViewArticleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ViewArticleServlet() {
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    
	    
	    ArticleDAO articleDAO = new ArticleDAO();
	    
        List<Article> fromSameAuthor = articleDAO.listByAuteur( Integer.parseInt(request.getParameter("aut")) );
        request.setAttribute( "fromSameAuthor", fromSameAuthor );
        
        List<Article> fromSameGenre = articleDAO.listByGenre( Integer.parseInt(request.getParameter("genre")) );
        request.setAttribute( "fromSameGenre", fromSameGenre );
        
        
	    ArticleServices articleServices = new ArticleServices(request, response);
        articleServices.viewArticleDetail();
        
	}

}
