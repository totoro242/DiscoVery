package com.discostore.controller.frontend.article;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.discostore.service.ArticleServices;

@WebServlet("/view_auteur")
public class ViewArticlesByAuteurServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ViewArticlesByAuteurServlet() {
       
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    request.setAttribute( "pageName", "artistsList" );
	    ArticleServices articleServices = new ArticleServices( request, response);
        
        articleServices.listArticlesByAuteur();
        
	}

}
