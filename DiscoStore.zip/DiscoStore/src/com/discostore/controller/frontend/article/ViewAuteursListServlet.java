package com.discostore.controller.frontend.article;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.discostore.service.AuteurServices;


@WebServlet("/view_auteurs_list")
public class ViewAuteursListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ViewAuteursListServlet() {
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    //AuteurServices auteurServices = new AuteurServices(request, response);
	    //auteurServices.listAuteurs();
	    request.setAttribute( "pageName", "artistsList" );
	    String listPage = "frontend/auteurs_list.jsp";
        RequestDispatcher requestDispatcher = request.getRequestDispatcher( listPage );
        requestDispatcher.forward( request, response );
        
	}

}
