package com.discostore.controller.admin;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@WebFilter("/admin/*")
public class AdminLoginFilter implements Filter {

    public AdminLoginFilter() {
    }

	public void destroy() {
		
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		System.out.println( "FILTRE admin activé" );
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		//Vérification que la session existe
		HttpSession session = httpRequest.getSession(false);
		//Vérification que la variable emailAdmin existe
		boolean loggedIn = session!= null && session.getAttribute("emailAdmin")!=null;
		//Permet d'accéder à la page de Login malgré le filtre
		String loginURI = httpRequest.getContextPath()+"/admin/login";
		boolean loginRequest = httpRequest.getRequestURI().equals( loginURI );
		boolean loginPage = httpRequest.getRequestURI().endsWith( "login.jsp" );
		
		if(loggedIn && (loginRequest || loginPage )) {
		    //Si l'admin est déjà loggué et qu'il rappelle la page de login
		    //On le redirige vers la page d'accueil de l'admin
		    RequestDispatcher dispatcher = request.getRequestDispatcher( "/admin/" );
            dispatcher.forward( request, response );
		    
		}else if(loggedIn || loginRequest) {
		    chain.doFilter(request, response);
		}else {
		    RequestDispatcher dispatcher = request.getRequestDispatcher( "login.jsp" );
		    dispatcher.forward( request, response );
		}
		
		
	}

	public void init(FilterConfig fConfig) throws ServletException {
		
	}

}
