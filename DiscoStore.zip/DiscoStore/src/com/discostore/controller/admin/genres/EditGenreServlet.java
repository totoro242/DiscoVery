package com.discostore.controller.admin.genres;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.discostore.service.GenreServices;

@WebServlet("/admin/edit_genre")
public class EditGenreServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public EditGenreServlet() {
        super();

    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    //Sert juste à rafficher les données de l'admin que l'on souhaite editer
	    GenreServices genreServices = new GenreServices( request, response);
	    genreServices.editGenre();
	}


}
