package com.discostore.controller.admin.client;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.discostore.service.ClientServices;

@WebServlet("/admin/delete_client")
public class DeleteClientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public DeleteClientServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    ClientServices clientServices = new ClientServices( request, response);
	    clientServices.deleteClient();
	}

}
