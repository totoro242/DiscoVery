package com.discostore.controller.admin.admins;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.discostore.service.AdminServices;

@WebServlet("/admin/edit_admin")
public class EditAdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public EditAdminServlet() {
        super();

    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    //Sert juste à rafficher les données de l'admin que l'on souhaite editer
	    AdminServices adminServices = new AdminServices( request, response);
	    adminServices.editAdmin();
	}


}
