package com.discostore.controller.admin.article;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.discostore.service.ArticleServices;

@WebServlet("/admin/create_article")
@MultipartConfig(
        //si le fichier dépasse 10kb, il sera stocké sur le disk
        fileSizeThreshold = 1024 * 10,  // 10 KB 
        //Taille maxi du fichier autorisée
        maxFileSize = 1024 * 300,       // 300 KB
        //Taille maxi de l'ensemble des datas du formulaire
        maxRequestSize = 1024 * 1024    // 1 MB 
)
public class CreateArticleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public CreateArticleServlet() {
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ArticleServices articleServices = new ArticleServices(request, response);
		articleServices.creatArticle();
	
	}

}
