package com.discostore.controller.admin.article;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.discostore.service.ArticleServices;

@WebServlet("/admin/list_articles")
public class ListArticleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ArticleServices articleServices = new ArticleServices( request, response);
        articleServices.listArticles();
	
	}

}
