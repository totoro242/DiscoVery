package com.discostore.service;

import java.io.IOException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.discostore.dao.FormatDAO;
import com.discostore.entity.Admin;
import com.discostore.entity.Auteur;


public class FormatServices {
   
    private FormatDAO            formatDAO;
    private HttpServletRequest  request;
    private HttpServletResponse response;

    public FormatServices( HttpServletRequest request, HttpServletResponse response ) {
        this.request = request;
        this.response = response;
        formatDAO = new FormatDAO();
    }
       


}
