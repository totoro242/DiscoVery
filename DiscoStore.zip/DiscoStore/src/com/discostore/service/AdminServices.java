package com.discostore.service;

import java.io.IOException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.discostore.dao.AdminDAO;
import com.discostore.entity.Admin;

public class AdminServices {
    
    private AdminDAO             adminDAO;
    private HttpServletRequest   request;
    private HttpServletResponse  response;

    public AdminServices(HttpServletRequest request, HttpServletResponse response ) {
        this.request = request;
        this.response = response;
        
        adminDAO = new AdminDAO();

    }

    public void listAdmins()
            throws ServletException, IOException {
        listAdmins( null );
    }

    public void listAdmins( String message ) throws ServletException, IOException {
        List<Admin> listAdmins = adminDAO.listAll();
        request.setAttribute( "listAdmins", listAdmins );

        if ( message != null ) {// Si on vient de crééer un nouvel admin
            request.setAttribute( "message", message );
        }
        String listPage = "admins_list.jsp";
        RequestDispatcher requestDispatcher = request.getRequestDispatcher( listPage );
        requestDispatcher.forward( request, response );
    }

    public void createAdmin() throws ServletException, IOException {
        String emailAdmin = request.getParameter( "email" );
        String nomAdmin = request.getParameter( "nom" );
        String prenomAdmin = request.getParameter( "prenom" );
        String mdpAdmin = request.getParameter( "password" );
        String statutAdmin = request.getParameter( "status" );

        if ( adminDAO.findByEmail( emailAdmin ) != null ) {
            String message = "Un admin utilise déjà l'email " + emailAdmin + ".";
            request.setAttribute( "message", message );
            RequestDispatcher dispatcher = request.getRequestDispatcher( "message.jsp" );
            dispatcher.forward( request, response );
        } else {
            Admin newAdmin = new Admin( emailAdmin, mdpAdmin, statutAdmin, nomAdmin, prenomAdmin );
            adminDAO.create( newAdmin );
            String message = "Un nouvel admin a été créé avec succès!";
            listAdmins( message );
        }
    }

    public void editAdmin() throws ServletException, IOException {
        // Recup les données de l'admin selectionné pour les afficher dans les
        // input du formulaire
        int adminId = Integer.parseInt( request.getParameter( "id" ) );
        Admin admin = adminDAO.get( adminId );
        String destPage = "admin_form.jsp";
        if ( admin == null ) {
            destPage = "message.jsp";
            String message = "Impossible de retrouver l'admin ayant pour ID " + adminId;
            request.setAttribute( "message", message );
        } else {
            request.setAttribute( "admin", admin );
        }
        RequestDispatcher requestDispatcher = request.getRequestDispatcher( destPage );
        requestDispatcher.forward( request, response );
    }

    public void updateAdmin() throws ServletException, IOException {
        // On récupère les details des champs du formulaire d'édition
        int idAdmin = Integer.parseInt( request.getParameter( "idAdmin" ) );
        String emailAdmin = request.getParameter( "email" );
        String nomAdmin = request.getParameter( "nom" );
        String prenomAdmin = request.getParameter( "prenom" );
        String mdpAdmin = request.getParameter( "password" );
        String statutAdmin = request.getParameter( "status" );

        // Recherche des infos de l'admin à updater
        Admin adminById = adminDAO.get( idAdmin );
        // Verification que l'email saisie n'est pas déjà présent en base
        Admin adminByEmail = adminDAO.findByEmail( emailAdmin );

        // Si on trouve un admin avec le mail saisi mais qu'il a un id différent
        // de celui qu'on veut updater alors:
        if ( adminByEmail != null && adminByEmail.getIdAdmin() != adminById.getIdAdmin() ) {
            String message = "Mise à jour impossible. Un admin avec l'email " + emailAdmin + " est déjà présent.";
            request.setAttribute( "message", message );

            RequestDispatcher requestDispatcher = request.getRequestDispatcher( "message.jsp" );
            requestDispatcher.forward( request, response );

        } else {
            // On créé un nouvel objet admin updaté
            Admin updatedAdmin = new Admin( idAdmin, emailAdmin, mdpAdmin, statutAdmin, nomAdmin, prenomAdmin );
            adminDAO.update( updatedAdmin );
            String message = "Admin modifié!";
            listAdmins( message );

        }
    }

    public void deleteAdmin() throws ServletException, IOException {
        int idAdmin = Integer.parseInt( request.getParameter( "id" ) );
        String message = "Admin supprimé!";
        //Si c'est l'admin par defaut (id=1 par exemple), on ne peut pas le supprimer
        if (idAdmin == 1) {
            message = "L'admin par défaut ne peut être supprimé.";
            
            request.setAttribute("message", message);
            request.getRequestDispatcher("message.jsp").forward(request, response);
            return;
        }

        Admin admin = adminDAO.get( idAdmin );
        

        if ( admin == null ) {
            message = "L'admin avec l'id = " + idAdmin + " est introuvable !";
            request.setAttribute( "message", message );
            request.getRequestDispatcher( "message.jsp" ).forward( request, response );

        } else {
            adminDAO.delete( idAdmin );
            listAdmins( message );
        }

    }
    
    public void login() throws ServletException, IOException {
        String email = request.getParameter( "email" );
        String password = request.getParameter( "password" );
        boolean isLoginOK = adminDAO.checkLogin( email, password );
        if(isLoginOK) {
            System.out.println( "authentification OK" );
            //Création d'une session avec le mail de l'admin
            request.getSession().setAttribute( "emailAdmin", email );
            //Renvoie à la page d'admin avec RequestDispatcher
            RequestDispatcher dispatcher = request.getRequestDispatcher( "/admin" );
            dispatcher.forward( request, response );
        }else {
            //Retour au formulaire de Login avec un message d'erreur
            String message = "Echec de l'authentification !";
            request.setAttribute( "message", message );
            System.out.println( "authentification not OK" );
            RequestDispatcher dispatcher = request.getRequestDispatcher( "login.jsp" );
            dispatcher.forward( request, response );
        }
    
    }
}
