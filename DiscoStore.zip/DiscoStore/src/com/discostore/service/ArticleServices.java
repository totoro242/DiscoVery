package com.discostore.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.discostore.dao.ArticleDAO;
import com.discostore.dao.AuteurDAO;
import com.discostore.dao.EditeurDAO;
import com.discostore.dao.FormatDAO;
import com.discostore.dao.GenreDAO;
import com.discostore.entity.Article;
import com.discostore.entity.Auteur;
import com.discostore.entity.Editeur;
import com.discostore.entity.Format;
import com.discostore.entity.Genre;

public class ArticleServices {
    private EntityManager       entityManager;
    private ArticleDAO          articleDAO;
    private AuteurDAO           auteurDAO;
    private GenreDAO            genreDAO;
    private FormatDAO           formatDAO;
    private EditeurDAO          editeurDAO;
    private HttpServletRequest  request;
    private HttpServletResponse response;

    public ArticleServices( HttpServletRequest request,
            HttpServletResponse response ) {
        super();
        this.request = request;
        this.response = response;
        articleDAO = new ArticleDAO();
        genreDAO = new GenreDAO();
        auteurDAO = new AuteurDAO();
        formatDAO = new FormatDAO();
        editeurDAO = new EditeurDAO();
    }

    public void listArticles() throws ServletException, IOException {
        listArticles( null );
    }

    public void listArticles( String message ) throws ServletException, IOException {
        List<Article> listArticles = articleDAO.listAll();
        request.setAttribute( "listArticles", listArticles );
        if ( message != null ) {
            request.setAttribute( "message", message );
        }
        String listPage = "articles_list.jsp";
        RequestDispatcher requestDispatcher = request.getRequestDispatcher( listPage );
        requestDispatcher.forward( request, response );
    }

    public void showArticleNewForm() throws ServletException, IOException {
        // Récup de la liste des genres, des auteurs, des formats et des
        // editeurs que l'on va stocker dans l'attribut
        // request pour le récupérer dans la jsp et remplir l'input select
        List<Genre> listGenres = genreDAO.listAll();
        request.setAttribute( "listGenres", listGenres );

        List<Auteur> listAuteurs = auteurDAO.listAll();
        request.setAttribute( "listAuteurs", listAuteurs );

        List<Format> listFormats = formatDAO.listAll();
        request.setAttribute( "listFormats", listFormats );

        List<Editeur> listEditeurs = editeurDAO.listAll();
        request.setAttribute( "listEditeurs", listEditeurs );

        String destPage = "article_form.jsp";
        RequestDispatcher requestDispatcher = request.getRequestDispatcher( destPage );
        requestDispatcher.forward( request, response );
    }

    // Test si c'est un entier
    public static Boolean isInteger( String val ) {
        Boolean reponse = true;
        int monInt;
        try {
            monInt = Integer.parseInt( val.trim() );
        } catch ( NumberFormatException e ) {
            reponse = false;
        }
        return reponse;
    }

    // Test si c'est un float
    public static Boolean isFloat( String val ) {
        Boolean reponse = true;
        float monFloat;
        try {
            monFloat = Float.parseFloat( val.trim() );
        } catch ( NumberFormatException e ) {
            reponse = false;
        }
        return reponse;
    }

    public void readArticleFields( Article article ) throws ServletException, IOException {

        if ( request.getParameter( "titre" ).trim().isEmpty()
                || !isInteger( request.getParameter( "auteur" ).trim() )
                || !isInteger( request.getParameter( "genre" ).trim() )
                || !isInteger( request.getParameter( "format" ).trim() )
                || !isInteger( request.getParameter( "stock" ).trim() )
                || !isFloat( request.getParameter( "prix" ).trim() )

        ) {
            listArticles( "Echec de l'enregistrement." );

        } else {

            String titre = request.getParameter( "titre" );
            Integer auteurId = Integer.parseInt( request.getParameter( "auteur" ) );
            Integer genreId = Integer.parseInt( request.getParameter( "genre" ) );
            Integer formatId = Integer.parseInt( request.getParameter( "format" ) );
            Integer editeurId = Integer.parseInt( request.getParameter( "editeur" ) );
            String description = request.getParameter( "description" );
            Integer nbTracks = 1;
            if ( !request.getParameter( "nbTracks" ).trim().isEmpty() && isInteger( request.getParameter( "stock" ).trim() ) ) {
                nbTracks = Integer.parseInt( request.getParameter( "nbTracks" ) );
            }

            String duree = request.getParameter( "duree" );
            String year = request.getParameter( "year" );
            float prix = Float.parseFloat( request.getParameter( "prix" ) );
            Integer stock = Integer.parseInt( request.getParameter( "stock" ) );

            Genre genre = genreDAO.get( genreId );
            article.setGenre( genre );

            Format format = formatDAO.get( formatId );
            article.setFormat( format );

            Editeur editeur = editeurDAO.get( editeurId );
            article.setEditeur( editeur );

            Auteur auteur = auteurDAO.get( auteurId );
            article.setAuteur( auteur );

            article.setTitre( titre );
            article.setDescription( description );
            article.setNbTracks( nbTracks );
            article.setTotalTime( duree );
            article.setYear( year );
            article.setPrix( prix );
            article.setStock( stock );

            // Pour l'image
            Part part = request.getPart( "articleImage" );

            if ( part != null && part.getSize() > 0 ) {
                long size = part.getSize();
                byte[] imageBytes = new byte[(int) size];

                InputStream inputStream = part.getInputStream();
                inputStream.read( imageBytes );
                inputStream.close();

                article.setImg( imageBytes );
            }
        }
    }

    public void creatArticle() throws IOException, ServletException {
        // Vérification que l'article est absent en base
        String titre = request.getParameter( "titre" );
        Integer auteurId = Integer.parseInt( request.getParameter( "auteur" ) );
        Auteur auteur = auteurDAO.get( auteurId );
        Article isArticleExist = articleDAO.checkExist( titre, auteur );

        if ( isArticleExist != null ) {
            String message = "L'article n'a pas été rajouté car '" + auteurDAO.get( auteurId ).getNomAuteur() + " - "
                    + titre + "' existe déjà.";
            listArticles( message );
            return;
        }

        Article newArticle = new Article();
        readArticleFields( newArticle );
        Article createdArticle = articleDAO.create( newArticle );

        if ( createdArticle.getRefArticle() > 0 ) {
            String message = "Nouvel article créé !";
            request.setAttribute( "message", message );
            listArticles( message );
        }

    }

    public void editArticle() throws ServletException, IOException {
        // Recup de l'id de l'article
        Integer articleId = Integer.parseInt( request.getParameter( "id" ) );
        Article article = articleDAO.get( articleId );
        if ( article != null ) {
            /*
             * On passse cet objet article en attribut du request pour pouvoir
             * le recuperer dans le form d'edition de l'article
             */
            request.setAttribute( "article", article );
            /*
             * Forward vers le formulaire d'edition
             */

            showArticleNewForm();
        } else {

            String message = "L'article avec l'ID " + articleId + " est introuvable.";
            request.setAttribute( "message", message );
            RequestDispatcher requestDispatcher = request.getRequestDispatcher( "message.jsp" );
            requestDispatcher.forward( request, response );
        }
    }

    public void updateArticle() throws ServletException, IOException {
        // Récup de l'id dans le champ hidden du formulaire
        Integer idArticle = Integer.parseInt( request.getParameter( "idArticle" ) );
        Article articleToUpdate = articleDAO.get( idArticle );

        // Vérification que l'update ne correspond pas à un article déjà en base
        String titre = request.getParameter( "titre" );
        Integer auteurId = Integer.parseInt( request.getParameter( "auteur" ) );
        Auteur auteur = auteurDAO.get( auteurId );
        Article articleAlreadyThere = articleDAO.checkExist( titre, auteur );

        if ( articleAlreadyThere != null &&
                !articleToUpdate.equals( articleAlreadyThere ) ) {
            String message = "L'article n'a pas été mis à jour car '" + auteurDAO.get( auteurId ).getNomAuteur() + " - "
                    + titre + "' existe déjà.";
            listArticles( message );
            return;
        }

        readArticleFields( articleToUpdate );
        articleDAO.update( articleToUpdate );
        String message = "Mise à jour réussie de l'article !";
        // Retour à la liste
        listArticles( message );
    }

    public void deleteArticle() throws ServletException, IOException {
        // Récup de l'id passé dans l'url
        Integer articleId = Integer.parseInt( request.getParameter( "id" ) );
        // articleDAO.delete( articleId );

        Article article = articleDAO.get( articleId );
        if ( article == null ) {

            String message = "L'article avec l'ID " + articleId + " est introuvable.";
            request.setAttribute( "message", message );
            request.getRequestDispatcher( "message.jsp" ).forward( request, response );

        } else {
            String message = "L'article a été supprimé avec succès!";
            articleDAO.delete( articleId );
            listArticles( message );
        }

    }

    public void listArticlesByGenre() throws ServletException, IOException {
        Integer genreId = Integer.parseInt( request.getParameter( "id" ) );
        Genre genre = genreDAO.get( genreId );

        if ( genre == null ) {
            String message = "Cette catégorie n'est pas disponible";
            request.setAttribute( "message", message );
            request.getRequestDispatcher( "frontend/message.jsp" ).forward( request, response );
            return;

        }

        List<Article> listArticles = articleDAO.listByGenre( genreId );

        /*
         * List<String> collection = new ArrayList<>(); for (Article article :
         * listArticles) {
         * 
         * collection.add( "{\"titre\":\""+ article.getTitre()+"\"" );
         * collection.add( "\"prix\":\""+ article.getPrix()+"\"" );
         * 
         * collection.add( "\"codAuteur\":\""+
         * article.getAuteur().getCodAuteur()+"\"" ); collection.add(
         * "\"codGenre\":\""+ article.getGenre().getCodGenre()+"\"" );
         * collection.add( "\"id\":\""+ article.getRefArticle()+"\"" );
         * collection.add( "\"artiste\":\""+
         * article.getAuteur().getNomAuteur()+"\"" );
         * 
         * if (article.getImg()!=null) { collection.add(
         * "\"image\":\"data:image//jpg;base64,"+ article.getBase64Image()+"\"}"
         * ); }else { collection.add( "\"image\":\""+
         * "http:////placehold.it//200"+"\"}" ); } } System.out.println(
         * collection );
         * 
         * request.setAttribute( "collection", collection );
         */
        request.setAttribute( "listArticles", listArticles );
        request.setAttribute( "genre", genre );

        String destPage = "frontend/articles_list_by_genre.jsp";
        RequestDispatcher requestDispatcher = request.getRequestDispatcher( destPage );
        requestDispatcher.forward( request, response );

    }

    public void listArticlesByAuteur() throws ServletException, IOException {
        Integer auteurId = Integer.parseInt( request.getParameter( "id" ) );
        Auteur auteur = auteurDAO.get( auteurId );

        if ( auteur == null ) {
            String message = "Cet auteur n'est pas disponible";
            request.setAttribute( "message", message );
            request.getRequestDispatcher( "frontend/message.jsp" ).forward( request, response );
            return;

        }

        List<Article> listArticles = articleDAO.listByAuteur( auteurId );

        request.setAttribute( "listArticles", listArticles );
        request.setAttribute( "auteur", auteur );

        String destPage = "frontend/articles_list_by_auteur.jsp";
        RequestDispatcher requestDispatcher = request.getRequestDispatcher( destPage );
        requestDispatcher.forward( request, response );

    }

    public void viewArticleDetail() throws ServletException, IOException {
        Integer articleId = Integer.parseInt( request.getParameter( "id" ) );
        Article article = articleDAO.get( articleId );

        if ( article != null ) {
            request.setAttribute( "article", article );
            String destPage = "frontend/article_detail.jsp";
            RequestDispatcher requestDispatcher = request.getRequestDispatcher( destPage );
            requestDispatcher.forward( request, response );
        } else {
            String message = "Désolé, l'article avec l'ID " + articleId + " n'est pas disponible.";
            request.setAttribute( "message", message );
            request.getRequestDispatcher( "frontend/message.jsp" ).forward( request, response );

        }

    }

    public void search() throws ServletException, IOException {
        String keyword = request.getParameter( "keyword" );
        List<Article> resultRech = null;
        // articleDAO.listAll();

        if ( keyword.equals( "" ) ) {
            resultRech = articleDAO.listAll();

        } else {
            resultRech = articleDAO.search( keyword );

        }
        request.setAttribute( "resultRech", resultRech );
        request.setAttribute( "keyword", keyword );
        String destPage = "frontend/search_result.jsp";
        RequestDispatcher requestDispatcher = request.getRequestDispatcher( destPage );
        requestDispatcher.forward( request, response );
    }

}
