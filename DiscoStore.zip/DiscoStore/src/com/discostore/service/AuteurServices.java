package com.discostore.service;

import java.io.IOException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.discostore.dao.AuteurDAO;
import com.discostore.entity.Admin;
import com.discostore.entity.Auteur;
import com.discostore.entity.Genre;


public class AuteurServices {
    private AuteurDAO            auteurDAO;
    private HttpServletRequest  request;
    private HttpServletResponse response;

    public AuteurServices(HttpServletRequest request, HttpServletResponse response ) {
        this.request = request;
        this.response = response;
        
        auteurDAO = new AuteurDAO();
    }
       
    public void createAuteur() throws ServletException, IOException {
        String nomAuteur = request.getParameter( "nouvelAuteur" ).trim();
        Auteur existAuteur = auteurDAO.findByName(nomAuteur);
        if (existAuteur != null) {
            String message = "L'auteur " + nomAuteur + " est déjà présent.";
            request.setAttribute( "message", message );
            RequestDispatcher requestDispatcher = request.getRequestDispatcher( "message.jsp" );
            requestDispatcher.forward( request, response );
        } else {
            Auteur newAuteur = new Auteur(nomAuteur);
            auteurDAO.create(newAuteur);
            /*
            Redirection vers la NewArticleServlet 
            */
            String destPage = "new_article";
            RequestDispatcher requestDispatcher = request.getRequestDispatcher( destPage );
            requestDispatcher.forward( request, response );           
        }  
    }


    public void listAuteurs() throws ServletException, IOException {
        List<Auteur> listAuteurs = auteurDAO.listAll();
        request.setAttribute( "listAuteurs", listAuteurs );
        String listPage = "frontend/auteurs_list.jsp";
        RequestDispatcher requestDispatcher = request.getRequestDispatcher( listPage );
        requestDispatcher.forward( request, response );
    }
}
