package com.discostore.service;

import java.io.IOException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.discostore.dao.ArticleDAO;
import com.discostore.dao.GenreDAO;
import com.discostore.entity.Admin;
import com.discostore.entity.Genre;

public class GenreServices {
    private GenreDAO            genreDAO;
    private HttpServletRequest  request;
    private HttpServletResponse response;

    public GenreServices( HttpServletRequest request, HttpServletResponse response ) {
        this.request = request;
        this.response = response;
        genreDAO = new GenreDAO();

    }
    public void listGenres() throws ServletException, IOException {
        listGenres(null);
    }
    public void listGenres(String message) throws ServletException, IOException {
        List<Genre> listGenres = genreDAO.listAll();
        request.setAttribute( "listGenres", listGenres );
        if(message !=null) {
            request.setAttribute( "message", message );
        }
        String listPage = "genres_list.jsp";
        RequestDispatcher requestDispatcher = request.getRequestDispatcher( listPage );
        requestDispatcher.forward( request, response );
    }

    public void createGenre() throws ServletException, IOException {
        
        String nomGenre = request.getParameter( "nom" );
        Genre existGenre = genreDAO.findByName(nomGenre);
        if (existGenre != null) {
            String message = "Le genre " + nomGenre + " est déjà présent.";
            request.setAttribute( "message", message );
            RequestDispatcher requestDispatcher = request.getRequestDispatcher( "message.jsp" );
            requestDispatcher.forward( request, response );
        } else {
            Genre newGenre = new Genre(nomGenre);
            genreDAO.create(newGenre);
            String message = "Nouveau genre créé avec succès!";
            listGenres(message);
        }


    }
    public void editGenre() throws ServletException, IOException {
        //Page de destination
        String destPage = "genre_form.jsp";
        //Recup de l'id passé dans l'url
        int genreId = Integer.parseInt( request.getParameter( "id" ));
        //Création d'un objet en partant de l'id récupéré
        Genre genre = genreDAO.get( genreId );
        //Vérification que l'id correspond bien à un genre       
        if ( genre == null ) {
          //Si le test Nok, on envoie un message d'erreur via la request à la page des messages
            destPage = "message.jsp";
            String message = "Impossible de retrouver le genre ayant pour ID " + genreId;
            request.setAttribute( "message", message );
        } else {
            request.setAttribute( "genre", genre );
        }
        //Si le test est ok, on envoie l'objet via la request au formulaire d'édition des genres
        RequestDispatcher requestDispatcher = request.getRequestDispatcher( destPage );
        requestDispatcher.forward( request, response );
        
    }
    public void updateGenre() throws ServletException, IOException {
        // On récupère les details des champs du formulaire d'édition
        int idGenre = Integer.parseInt( request.getParameter( "idGenre" ) ); //input hidden du form
        String nomGenre = request.getParameter( "nom" );      
        // Recherche des infos du genre à updater
        Genre genreToUpdate = genreDAO.get( idGenre );
        // Verification que le genre saisie n'est pas déjà attribué
        Genre existGenre = genreDAO.findByName(nomGenre);
        if (existGenre != null) {
            String message = "Le genre " + nomGenre + " est déjà présent.";
            request.setAttribute( "message", message );
            RequestDispatcher requestDispatcher = request.getRequestDispatcher( "message.jsp" );
            requestDispatcher.forward( request, response );
        } else {
            genreToUpdate.setIntituleGenre( nomGenre );
            genreDAO.update( genreToUpdate );
            String message = "Le genre a été modifié!";
            listGenres( message );     
        }       
    }
    public void deleteGenre() throws ServletException, IOException {
        int idGenre = Integer.parseInt( request.getParameter( "id" ) );
        String message;     
        Genre genre = genreDAO.get(idGenre);
        //Le genre existe_t_il?
        if ( genre == null ) {
            message = "Le genre avec l'id = " + idGenre + " est introuvable !";
            request.setAttribute( "message", message );
            request.getRequestDispatcher( "message.jsp" ).forward( request, response );
            return;
        } 
        //Le genre contient-il des articles?
        ArticleDAO articleDAO = new ArticleDAO();
        Long nbArticles = articleDAO.countByGenre(idGenre);
        if(nbArticles>0) {
            message = "Impossible de supprimer le genre "+idGenre+ " car il contient des articles.";
            
        }
        else {
            genreDAO.delete( idGenre );
            message = "Le genre "+idGenre+ " a été supprimé!";     
        }
        
            listGenres( message );
     
    }

}
