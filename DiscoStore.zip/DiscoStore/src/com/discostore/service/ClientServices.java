package com.discostore.service;

import java.io.IOException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.discostore.dao.ClientDAO;
import com.discostore.entity.Admin;
import com.discostore.entity.Client;
public class ClientServices {

    
    private ClientDAO             clientDAO;
    private HttpServletRequest   request;
    private HttpServletResponse  response;

    public ClientServices(HttpServletRequest request, HttpServletResponse response ) {
        this.request = request;
        this.response = response;    
        this.clientDAO = new ClientDAO();

    }

    public void listClients()
            throws ServletException, IOException {
        listClients( null );
    }

    public void listClients( String message ) throws ServletException, IOException {
        List<Client> listClients = clientDAO.listAll();
        request.setAttribute( "listClients", listClients );

        if ( message != null ) {// Si on vient de crééer un nouveau client
            request.setAttribute( "message", message );
        }
        String listPage = "clients_list.jsp";
        RequestDispatcher requestDispatcher = request.getRequestDispatcher( listPage );
        requestDispatcher.forward( request, response );
    }
    public void recupChamps(Client client) {
        String email = request.getParameter( "email" );
        String nom = request.getParameter( "nom" );
        String prenom = request.getParameter( "prenom" );
        String password = request.getParameter( "password" );
        String phone = request.getParameter( "phone" );
        String adresse = request.getParameter( "adresse" );
        String adresse2 = request.getParameter( "adresse2" );
        String cp = request.getParameter( "cp" );
        String ville = request.getParameter( "ville" );
        String pays = request.getParameter( "pays" );
        
        client.setMail( email );
        client.setNomCli( nom );
        client.setPrenomCli( prenom );
        client.setMdpCli( password );
        client.setPhone( phone );
        client.setAddressLine1( adresse );
        client.setAddressLine2( adresse2 );
        client.setCp( cp );
        client.setVille( ville );
        client.setPays( pays );
        
    }
    public void createClient() throws ServletException, IOException {
        //Récup des saisies
        String email = request.getParameter( "email" );
        //Vérif qu'un client n'utilise pas déjà cet email
        if ( clientDAO.findByEmail( email ) != null ) {
            String message = "Un client utilise déjà l'email " + email + ".";
            request.setAttribute( "message", message );
            RequestDispatcher dispatcher = request.getRequestDispatcher( "message.jsp" );
            dispatcher.forward( request, response );
        } else {
            Client newClient = new Client();
            recupChamps(newClient);
            clientDAO.create( newClient );
            String message = "Un nouveau client a été ajouté avec succès!";
            listClients( message );
        }
    
    }

    public void registerClient() throws ServletException, IOException {
        //Récup des saisies
        String email = request.getParameter( "email" );
        
        String message;
        //Vérif qu'un client n'utilise pas déjà cet email
        if ( clientDAO.findByEmail( email ) != null ) {
            message = "Un client utilise déjà l'email " + email + ".";
            
        } else {
            
            Client newClient = new Client();
            recupChamps(newClient);
            clientDAO.create( newClient );
            message = "Vous vous êtes enregistré avec succès!<br/>"
                    + "<a href='login'>Suiver ce lien</a> pour vous connecter.";
        }
        request.setAttribute( "message", message );
        RequestDispatcher dispatcher = request.getRequestDispatcher( "frontend/message.jsp" );
        dispatcher.forward( request, response );
    }    
    
    public void editClient() throws ServletException, IOException {
        // Recup des données connues en base du client selectionné pour les afficher dans le
        // formulaire
        int clientId = Integer.parseInt( request.getParameter( "id" ) );
        Client client = clientDAO.get( clientId );
        String destPage = "client_form.jsp";
        if ( client == null ) {
            destPage = "message.jsp";
            String message = "Impossible de retrouver le client ayant pour ID " + clientId;
            request.setAttribute( "message", message );
        } else {
            request.setAttribute( "client", client );
        }
        RequestDispatcher requestDispatcher = request.getRequestDispatcher( destPage );
        requestDispatcher.forward( request, response );
        
    }

    public void updateClient() throws ServletException, IOException {
        int idClient = Integer.parseInt( request.getParameter( "idClient" ) );
        String email = request.getParameter( "email" );

        // Verification que l'email saisie n'est pas déjà présent en base
        Client clientByEmail = clientDAO.findByEmail( email );

        // Si on trouve un admin avec le mail saisi mais qu'il a un id différent
        // de celui qu'on veut updater alors:
        
        if ( clientByEmail != null && clientByEmail.getNumCli() != idClient ) {
            String message = "Mise à jour impossible. Un client avec l'email " + email + " est déjà présent.";
            request.setAttribute( "message", message );

            RequestDispatcher requestDispatcher = request.getRequestDispatcher( "message.jsp" );
            requestDispatcher.forward( request, response );

        } else {
            // On créé un nouvel objet client updaté
            

            // Recherche des infos du client à modifier
            Client clientById = clientDAO.get( idClient );
            //Client updatedClient = new Client();
            recupChamps(clientById);
            clientDAO.update( clientById );
            String message = "Client modifié!";
            listClients( message );

        }
        
    }

    public void deleteClient() throws ServletException, IOException {
        
        //TODO : verifier que le client à effacer n'a pas de commandes en cours
        int idClient = Integer.parseInt( request.getParameter( "id" ) );
        String message = "Client supprimé!";
 
        Client client = clientDAO.get( idClient );
        

        if ( client == null ) {
            message = "Le client avec l'id = " + idClient + " est introuvable !";
            request.setAttribute( "message", message );
            request.getRequestDispatcher( "message.jsp" ).forward( request, response );

        } else {
            clientDAO.delete( idClient );
            listClients( message );
        }
        
    }

    public void showLogin() throws ServletException, IOException {
        String loginPage ="frontend/login.jsp";
        RequestDispatcher dispatcher = request.getRequestDispatcher( loginPage );
        dispatcher.forward( request, response );
    }

    public void doLogin() throws ServletException, IOException {
        String email = request.getParameter( "email" );
        String password = request.getParameter( "password" );
        Client client = clientDAO.checkLogin( email, password );
        if(client==null) {
            //Message d'erreur et raffichage du form de login
            String message = "La connexion a échouée. Vérifiez vos email et mot de passe.";
            request.setAttribute( "message", message );
            showLogin();
        }else {
            //Creation d'une variable de session dans lequel on place l'objet Client retourné
            //par la methode checkLogin
            request.getSession().setAttribute( "loggedClient", client );
            //Si le client s'est connecté on affiche son profil
            showClientProfile();
        }
    }
    public void showClientProfile() throws ServletException, IOException {
      //Affichage de la page de profil du client
        String profilePage ="frontend/client_profile.jsp";
        RequestDispatcher dispatcher = request.getRequestDispatcher( profilePage );
        dispatcher.forward( request, response );
    }
}
