package com.discostore.dao;

import java.util.List;

import javax.persistence.EntityManager;

import com.discostore.entity.Editeur;


public class EditeurDAO extends JpaDAO<Editeur> implements GenericDAO<Editeur> {

    public EditeurDAO() {
     
    }
/*
    @Override
    public Format create( Format format ) {
        
        return super.create( format );
    }

    /*
    public Auteur findByName( String nomAuteur ) {
        List<Auteur> result = super.findAllWithNamedQuery("Auteur.findByName", "nom", nomAuteur);       
        if (result != null && result.size() > 0) {
            return result.get(0);
        }      
        return null;
    }
    
    */
    
    @Override
    public Editeur get( Object editeurId ) {
        return super.find( Editeur.class, editeurId );
    }

    @Override
    public void delete( Object id ) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public List<Editeur> listAll() {
        return super.findAllWithNamedQuery( "Editeur.findAll" );
    }


    
    
    @Override
    public long count() {
        // TODO Auto-generated method stub
        return 0;
    }



}
