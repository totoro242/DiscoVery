package com.discostore.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.discostore.entity.Admin;
import com.discostore.entity.Client;

public class ClientDAO extends JpaDAO<Client> implements GenericDAO<Client> {

    @Override
    public Client create( Client client ) {
        // TODO Auto-generated method stub
        return super.create( client );
    }

    @Override
    public Client get( Object id ) {
       
        return super.find( Client.class, id );
    }

    @Override
    public void delete( Object id ) {
        super.delete( Client.class, id );
        
    }

    @Override
    public List<Client> listAll() {
        return super.findAllWithNamedQuery( "Client.findAll" );
    }

    @Override
    public long count() {
        return super.countWithNamedQuery( "Client.countAll" );
    }

    // Vérifie que le mail n'est pas déjà présent
    public Client findByEmail( String email ) {
        List<Client> listClients = super.findAllWithNamedQuery( "Client.findByEmail", "email", email );

        if ( listClients != null && listClients.size() > 0 ) {
            return listClients.get( 0 );
        }
        return null;
    }
    
    //Methode qui retourne un objet Client si le login/password est OK
    public Client checkLogin(String email, String password) {
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("email", email);
        parameters.put("password", password);
        //Appel de la methode de la superclass jpaDAO findAllWithNamedQuery avec en paramètres:
        //La namedQuery checkLogin (requète sql présente dans l'entity Client)
        // Ainsi que les identifiants  à vérifier (mis dans une map) 
        List<Client> result = super.findAllWithNamedQuery("Client.checkLogin", parameters);
        
        if (!result.isEmpty()) {
            return result.get(0);
        }
        
        return null;
    }
}
