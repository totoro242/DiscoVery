package com.discostore.dao;

import java.util.List;

import javax.persistence.EntityManager;

import com.discostore.entity.Genre;

public class GenreDAO extends JpaDAO<Genre> implements GenericDAO<Genre> {

    public GenreDAO() {
    }

    @Override
    public Genre create( Genre genre ) {
        
        return super.create( genre );
    }

    @Override
    public Genre update( Genre genre ) {
        return super.update( genre );
    }

    @Override
    public Genre get( Object id ) {
        return super.find( Genre.class, id );
    }

    @Override
    public void delete( Object id ) {
        super.delete( Genre.class, id );
        
    }

    @Override
    public List<Genre> listAll() {
        return super.findAllWithNamedQuery( "Genre.findAll" );
    }

    @Override
    public long count() {
        return super.countWithNamedQuery( "Genre.countAll" );
        
    }

    public Genre findByName( String nomGenre ) {
        List<Genre> result = super.findAllWithNamedQuery("Genre.findByName", "nom", nomGenre);
        
        if (result != null && result.size() > 0) {
            return result.get(0);
        }
        
        return null;

        
        
        
    }

}
