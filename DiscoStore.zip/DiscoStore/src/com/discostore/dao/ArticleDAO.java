package com.discostore.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.discostore.entity.Admin;
import com.discostore.entity.Article;
import com.discostore.entity.Auteur;

public class ArticleDAO extends JpaDAO<Article> implements GenericDAO<Article> {

    public ArticleDAO() {
    }

    @Override
    public Article create( Article article ) {
        return super.create( article );
    }

    @Override
    public Article update( Article article ) {
        return super.update( article );
    }

    @Override
    public Article get( Object articleId ) {
        return super.find( Article.class, articleId );
    }

    @Override
    public void delete( Object articleId ) {
        super.delete( Article.class, articleId );

    }

    @Override
    public List<Article> listAll() {
        // Récuperation de tous les articles de la DB via la named query de
        // l'entity Article
        return super.findAllWithNamedQuery( "Article.findAll" );
    }

    public Article findByTitle( String title ) {
        List<Article> result = super.findAllWithNamedQuery( "Article.findByTitle", "title", title );
        if ( !result.isEmpty() ) {
            return result.get( 0 );
        }
        return null;
    }

    
    public Article checkExist( String titre, Auteur auteur  ) {
        // On met les parametres titre et id de l'auteur dans une Map
        Map<String, Object> parameters = new HashMap<>();
        parameters.put( "titre", titre );
        parameters.put( "auteur", auteur );
        // Appel de la @NamedQuery Article.checkExist présente dans l'entity Article
        List<Article> result = super.findAllWithNamedQuery( "Article.checkExist", parameters );
        if ( !result.isEmpty() ) {
            return result.get( 0 );
        }
        return null;
    }
    
    
   public List<Article > listByGenre(int genreId){
       //appel de la namedQuery correspondant
       return super.findAllWithNamedQuery( "Article.findByGenre", "genreId", genreId  ) ;
   }
    

   public List<Article > listByAuteur(int auteurId){
       //appel de la namedQuery correspondant
       return super.findAllWithNamedQuery( "Article.findByAuteur", "auteurId", auteurId  ) ;
   }
   
   public List<Article > listNewArticles(){
       return super.findAllWithNamedQuery( "Article.listNew" , 0, 8);
   }
    
   public List<Article > listBestSells(){
       return super.findAllWithNamedQuery( "Article.listBestSells" , 0, 8);
   }
   
   public List<Article> search(String keyword) {
       return super.findAllWithNamedQuery("Article.search", "keyword", keyword);
   }
   
   
   public Long countByGenre(int id) {
       return super.countWithNamedQuery( "Article.countByGenre", "idGenre", id );
   }
   
   
   
    @Override
    public long count() {
        return super.countWithNamedQuery( "Article.countAll" );
    }

}
