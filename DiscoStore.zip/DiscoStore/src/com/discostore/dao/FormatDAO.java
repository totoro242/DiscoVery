package com.discostore.dao;

import java.util.List;

import javax.persistence.EntityManager;

import com.discostore.entity.Format;


public class FormatDAO extends JpaDAO<Format> implements GenericDAO<Format> {

    public FormatDAO() {
    }
    
    
/*
    @Override
    public Format create( Format format ) {
        
        return super.create( format );
    }

    /*
    public Auteur findByName( String nomAuteur ) {
        List<Auteur> result = super.findAllWithNamedQuery("Auteur.findByName", "nom", nomAuteur);       
        if (result != null && result.size() > 0) {
            return result.get(0);
        }      
        return null;
    }
    
    */
    
    @Override
    public Format get( Object formatId ) {
        return super.find( Format.class, formatId );
    }

    @Override
    public void delete( Object id ) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public List<Format> listAll() {
        return super.findAllWithNamedQuery( "Format.findAll" );
    }


    
    
    @Override
    public long count() {
        // TODO Auto-generated method stub
        return 0;
    }



}
