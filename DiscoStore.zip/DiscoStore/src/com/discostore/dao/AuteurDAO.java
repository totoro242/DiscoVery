package com.discostore.dao;

import java.util.List;

import javax.persistence.EntityManager;

import com.discostore.entity.Article;
import com.discostore.entity.Auteur;
import com.discostore.entity.Genre;


public class AuteurDAO extends JpaDAO<Auteur> implements GenericDAO<Auteur> {

    public AuteurDAO() {
    }

    @Override
    public Auteur create( Auteur auteur ) {
        
        return super.create( auteur );
    }

    
    public Auteur findByName( String nomAuteur ) {
        List<Auteur> result = super.findAllWithNamedQuery("Auteur.findByName", "nom", nomAuteur);       
        if (result != null && result.size() > 0) {
            return result.get(0);
        }      
        return null;
    }
    
    
    
    @Override
    public Auteur get( Object auteurId ) {
        return super.find( Auteur.class, auteurId );
    }

    @Override
    public void delete( Object id ) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public List<Auteur> listAll() {
        return super.findAllWithNamedQuery( "Auteur.findAll" );
    }


    
    
    @Override
    public long count() {
        // TODO Auto-generated method stub
        return 0;
    }



}
