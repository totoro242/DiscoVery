package com.discostore.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.NamedQuery;

import com.discostore.entity.Admin;

public class AdminDAO extends JpaDAO<Admin> implements GenericDAO<Admin> {

    public AdminDAO() {
    }

    public Admin create( Admin admin ) {
        return super.create( admin );
    }

    @Override
    public Admin update( Admin admin ) {
        return super.update( admin );
    }

    @Override
    public Admin get( Object adminId ) {
        return super.find( Admin.class, adminId );
    }

    // Vérifie que le mail n'est pas déjà présent
    public Admin findByEmail( String email ) {
        List<Admin> listAdmins = super.findAllWithNamedQuery( "Admin.findByEmail", "email", email );

        if ( listAdmins != null && listAdmins.size() > 0 ) {
            return listAdmins.get( 0 );
        }

        return null;
    }

    public boolean checkLogin( String email, String password ) {
        // On met les parametres email et password dans une Map
        Map<String, Object> parameters = new HashMap<>();
        parameters.put( "email", email );
        parameters.put( "password", password );
        // Appel de la @NamedQuery Admin.checkLogin() présente dans l'entity
        // Admin
        List<Admin> listAdmins = super.findAllWithNamedQuery( "Admin.checkLogin", parameters );
        if ( listAdmins.size() == 1 ) {
            return true;
        }
        return false;
    }

    @Override
    public void delete( Object adminId ) {
        super.delete( Admin.class, adminId );

    }

    @Override
    public List<Admin> listAll() {
        return super.findAllWithNamedQuery( "Admin.findAll" );
    }

    @Override
    public long count() {
        return super.countWithNamedQuery( "Admin.countAll" );
    }

}
