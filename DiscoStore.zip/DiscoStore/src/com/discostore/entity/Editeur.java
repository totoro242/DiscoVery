package com.discostore.entity;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table( name = "editeur", catalog = "disco" )
@NamedQueries( {
    @NamedQuery( name = "Editeur.findAll", query = "SELECT e FROM Editeur e ORDER BY e.nomEditeur" ),
   
} )
public class Editeur implements java.io.Serializable {

    private Integer      codEditeur;
    private String       nomEditeur;
    private Set<Article> articles = new HashSet<Article>( 0 );

    public Editeur() {
    }

    public Editeur( String nomEditeur, Set<Article> articles ) {
        this.nomEditeur = nomEditeur;
        this.articles = articles;
    }

    @Id
    @GeneratedValue( strategy = IDENTITY )

    @Column( name = "codEditeur", unique = true, nullable = false )
    public Integer getCodEditeur() {
        return this.codEditeur;
    }

    public void setCodEditeur( Integer codEditeur ) {
        this.codEditeur = codEditeur;
    }

    @Column( name = "nomEditeur", length = 50 )
    public String getNomEditeur() {
        return this.nomEditeur;
    }

    public void setNomEditeur( String nomEditeur ) {
        this.nomEditeur = nomEditeur;
    }

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "editeur" )
    public Set<Article> getArticles() {
        return this.articles;
    }

    public void setArticles( Set<Article> articles ) {
        this.articles = articles;
    }

}
