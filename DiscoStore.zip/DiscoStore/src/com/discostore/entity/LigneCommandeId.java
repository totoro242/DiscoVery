package com.discostore.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;


@Embeddable
public class LigneCommandeId implements java.io.Serializable {

    private int refCommande;
    private int refArticle;

    public LigneCommandeId() {
    }

    public LigneCommandeId( int refCommande, int refArticle ) {
        this.refCommande = refCommande;
        this.refArticle = refArticle;
    }

    @Column( name = "refCommande", nullable = false )
    public int getRefCommande() {
        return this.refCommande;
    }

    public void setRefCommande( int refCommande ) {
        this.refCommande = refCommande;
    }

    @Column( name = "refArticle", nullable = false )
    public int getRefArticle() {
        return this.refArticle;
    }

    public void setRefArticle( int refArticle ) {
        this.refArticle = refArticle;
    }

    public boolean equals( Object other ) {
        if ( ( this == other ) )
            return true;
        if ( ( other == null ) )
            return false;
        if ( !( other instanceof LigneCommandeId ) )
            return false;
        LigneCommandeId castOther = (LigneCommandeId) other;

        return ( this.getRefCommande() == castOther.getRefCommande() )
                && ( this.getRefArticle() == castOther.getRefArticle() );
    }

    public int hashCode() {
        int result = 17;

        result = 37 * result + this.getRefCommande();
        result = 37 * result + this.getRefArticle();
        return result;
    }

}
