package com.discostore.entity;

import java.util.Base64;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;


@Entity
@Table( name = "article", catalog = "disco" )

@NamedQueries( {
        @NamedQuery( name = "Article.findAll", query = "SELECT a FROM Article a ORDER BY a.refArticle DESC" ),
        @NamedQuery( name = "Article.findByTitle", query = "SELECT a FROM Article a WHERE a.titre = :title" ),
        @NamedQuery( name = "Article.countAll", query = "SELECT COUNT(*) FROM Article a" ),
        
        @NamedQuery(name = "Article.countByGenre", query = "SELECT COUNT(a) FROM Article a "
                + "WHERE a.genre.codGenre = :idGenre"),
        
        
        
        @NamedQuery( name = "Article.checkExist", query = "SELECT a FROM Article a WHERE a.titre = :titre AND a.auteur = :auteur" ),
        @NamedQuery( name = "Article.findByGenre",
        query = "SELECT a FROM Article a "
                + "JOIN Genre g ON a.genre.codGenre = g.codGenre "
                + "AND g.codGenre = :genreId" ),
        
        @NamedQuery( name = "Article.findByAuteur",
        query = "SELECT a FROM Article a "
                + "JOIN Auteur aut ON a.auteur.codAuteur = aut.codAuteur "
                + "AND aut.codAuteur = :auteurId" ),
        
        @NamedQuery( name = "Article.listNew", query = "SELECT a FROM Article a ORDER BY a.year DESC" ),
        
        
        @NamedQuery( name = "Article.listBestSells", query = "SELECT a FROM Article a "
                + "JOIN LigneCommande lc ON a.refArticle = lc.article.refArticle "
                + "group by a.refArticle Order by sum(lc.qtyOrdered) desc" ),
        
        @NamedQuery(name = "Article.search", query = "SELECT a FROM Article a WHERE a.titre LIKE '%' || :keyword || '%'"
                + " OR a.auteur.nomAuteur LIKE '%' || :keyword || '%'"
                + " OR a.description LIKE '%' || :keyword || '%'")
        
        
        
} )

public class Article implements java.io.Serializable {

    private Integer            refArticle;
    private Auteur             auteur;
    private Editeur            editeur;
    private Format             format;
    private Genre              genre;
    private String             titre;
    private Float              prix;
    private String             description;
    private String             photo;
    private int                stock;
    private Integer            nbTracks;
    private String             year;
    private String             totalTime;
    private byte[]             img;
    private String             base64Image;
    private Set<LigneCommande> ligneCommandes = new HashSet<LigneCommande>( 0 );

    public Article() {
    }

    public Article( Auteur auteur, Format format, Genre genre, String titre, int stock ) {
        this.auteur = auteur;
        this.format = format;
        this.genre = genre;
        this.titre = titre;
        this.stock = stock;
    }

    public Article( Auteur auteur, Editeur editeur, Format format, Genre genre, String titre, Float prix,
            String description, String photo, int stock, Integer nbTracks, String year, String totalTime, byte[] img,
            Set<LigneCommande> ligneCommandes ) {
        this.auteur = auteur;
        this.editeur = editeur;
        this.format = format;
        this.genre = genre;
        this.titre = titre;
        this.prix = prix;
        this.description = description;
        this.photo = photo;
        this.stock = stock;
        this.nbTracks = nbTracks;
        this.year = year;
        this.totalTime = totalTime;
        this.img = img;
        this.ligneCommandes = ligneCommandes;
    }

    @Id
    @GeneratedValue( strategy = IDENTITY )

    @Column( name = "refArticle", unique = true, nullable = false )
    public Integer getRefArticle() {
        return this.refArticle;
    }

    public void setRefArticle( Integer refArticle ) {
        this.refArticle = refArticle;
    }

    @ManyToOne( fetch = FetchType.EAGER )
    @JoinColumn( name = "codAuteur", nullable = false )
    public Auteur getAuteur() {
        return this.auteur;
    }

    public void setAuteur( Auteur auteur ) {
        this.auteur = auteur;
    }

    @ManyToOne( fetch = FetchType.EAGER )
    @JoinColumn( name = "codEditeur" )
    public Editeur getEditeur() {
        return this.editeur;
    }

    public void setEditeur( Editeur editeur ) {
        this.editeur = editeur;
    }

    @ManyToOne( fetch = FetchType.EAGER )
    @JoinColumn( name = "codFormat", nullable = false )
    public Format getFormat() {
        return this.format;
    }

    public void setFormat( Format format ) {
        this.format = format;
    }

    @ManyToOne( fetch = FetchType.EAGER )
    @JoinColumn( name = "codGenre", nullable = false )
    public Genre getGenre() {
        return this.genre;
    }

    public void setGenre( Genre genre ) {
        this.genre = genre;
    }

    @Column( name = "titre", nullable = false, length = 120 )
    public String getTitre() {
        return this.titre;
    }

    public void setTitre( String titre ) {
        this.titre = titre;
    }

    @Column( name = "prix", precision = 12, scale = 0 )
    public Float getPrix() {
        return this.prix;
    }

    public void setPrix( Float prix ) {
        this.prix = prix;
    }

    @Column( name = "description" )
    public String getDescription() {
        return this.description;
    }

    public void setDescription( String description ) {
        this.description = description;
    }

    @Column( name = "photo", length = 120 )
    public String getPhoto() {
        return this.photo;
    }

    public void setPhoto( String photo ) {
        this.photo = photo;
    }

    @Column( name = "stock", nullable = false )
    public int getStock() {
        return this.stock;
    }

    public void setStock( int stock ) {
        this.stock = stock;
    }

    @Column( name = "nbTracks" )
    public Integer getNbTracks() {
        return this.nbTracks;
    }

    public void setNbTracks( Integer nbTracks ) {
        this.nbTracks = nbTracks;
    }

    @Column( name = "year", length = 50 )
    public String getYear() {
        return this.year;
    }

    public void setYear( String year ) {
        this.year = year;
    }

    @Column( name = "totalTime", length = 45 )
    public String getTotalTime() {
        return this.totalTime;
    }

    public void setTotalTime( String totalTime ) {
        this.totalTime = totalTime;
    }

    @Column( name = "img" )
    public byte[] getImg() {
        return this.img;
    }

    public void setImg( byte[] img ) {
        this.img = img;
    }

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "article" )
    public Set<LigneCommande> getLigneCommandes() {
        return this.ligneCommandes;
    }

    public void setLigneCommandes( Set<LigneCommande> ligneCommandes ) {
        this.ligneCommandes = ligneCommandes;
    }
    @Transient
    public String getBase64Image() {
        this.base64Image = Base64.getEncoder().encodeToString( this.img );
        return this.base64Image;
    }
    @Transient
    public void setBase64Image( String base64Image ) {
        this.base64Image = base64Image;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ( ( refArticle == null ) ? 0 : refArticle.hashCode() );
        return result;
    }

    @Override
    public boolean equals( Object obj ) {
        if ( this == obj )
            return true;
        if ( obj == null )
            return false;
        if ( getClass() != obj.getClass() )
            return false;
        Article other = (Article) obj;
        if ( refArticle == null ) {
            if ( other.refArticle != null )
                return false;
        } else if ( !refArticle.equals( other.refArticle ) )
            return false;
        return true;
    }
    
    
    
    
}
