package com.discostore.entity;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table( name = "format", catalog = "disco" )

@NamedQueries( {
    @NamedQuery( name = "Format.findAll", query = "SELECT f FROM Format f" ),
   
} )
public class Format implements java.io.Serializable {

    private int      codFormat;
    private String       descriptionFormat;
    private Set<Article> articles = new HashSet<Article>( 0 );

    public Format() {
    }

    public Format( String descriptionFormat ) {
        this.descriptionFormat = descriptionFormat;
    }

    
    public Format( int codFormat, String descriptionFormat ) {
        this.codFormat = codFormat;
        this.descriptionFormat = descriptionFormat;
    }
    
    public Format( String descriptionFormat, Set<Article> articles ) {
        this.descriptionFormat = descriptionFormat;
        this.articles = articles;
    }

    @Id
    @GeneratedValue( strategy = IDENTITY )

    @Column( name = "codFormat", unique = true, nullable = false )
    public Integer getCodFormat() {
        return this.codFormat;
    }

    public void setCodFormat( Integer codFormat ) {
        this.codFormat = codFormat;
    }

    @Column( name = "descriptionFormat", nullable = false, length = 60 )
    public String getDescriptionFormat() {
        return this.descriptionFormat;
    }

    public void setDescriptionFormat( String descriptionFormat ) {
        this.descriptionFormat = descriptionFormat;
    }

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "format" )
    public Set<Article> getArticles() {
        return this.articles;
    }

    public void setArticles( Set<Article> articles ) {
        this.articles = articles;
    }

}
