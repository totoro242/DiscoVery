package com.discostore.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table( name = "admin", catalog = "disco" )

@NamedQueries( {
        @NamedQuery( name = "Admin.findAll", query = "SELECT a FROM Admin a ORDER BY a.idAdmin DESC" ),
        @NamedQuery( name = "Admin.countAll", query = "SELECT Count(*) FROM Admin a" ),
        @NamedQuery( name = "Admin.findByEmail", query = "SELECT a FROM Admin a WHERE a.emailAdmin= :email" ),
        @NamedQuery( name = "Admin.checkLogin", query = "SELECT a FROM Admin a WHERE a.emailAdmin= :email AND a.mdpAdmin= :password" )
} )

public class Admin implements java.io.Serializable {

    private Integer idAdmin;
    private String  emailAdmin;
    private String  mdpAdmin;
    private String  statutAdmin;
    private String  nomAdmin;
    private String  prenomAdmin;

    public Admin() {
    }

    // Constructeur avec le l'idAdmin utile pour l'update
    public Admin( Integer idAdmin, String emailAdmin, String mdpAdmin, String statutAdmin, String nomAdmin,
            String prenomAdmin ) {
        this.idAdmin = idAdmin;
        this.emailAdmin = emailAdmin;
        this.mdpAdmin = mdpAdmin;
        this.statutAdmin = statutAdmin;
        this.nomAdmin = nomAdmin;
        this.prenomAdmin = prenomAdmin;
    }

    public Admin( String emailAdmin, String mdpAdmin, String statutAdmin, String nomAdmin, String prenomAdmin ) {
        this.emailAdmin = emailAdmin;
        this.mdpAdmin = mdpAdmin;
        this.statutAdmin = statutAdmin;
        this.nomAdmin = nomAdmin;
        this.prenomAdmin = prenomAdmin;
    }

    @Id
    @GeneratedValue( strategy = IDENTITY )

    @Column( name = "idAdmin", unique = true, nullable = false )
    public Integer getIdAdmin() {
        return this.idAdmin;
    }

    public void setIdAdmin( Integer idAdmin ) {
        this.idAdmin = idAdmin;
    }

    @Column( name = "emailAdmin", nullable = false, length = 45 )
    public String getEmailAdmin() {
        return this.emailAdmin;
    }

    public void setEmailAdmin( String emailAdmin ) {
        this.emailAdmin = emailAdmin;
    }

    @Column( name = "mdpAdmin", nullable = false, length = 20 )
    public String getMdpAdmin() {
        return this.mdpAdmin;
    }

    public void setMdpAdmin( String mdpAdmin ) {
        this.mdpAdmin = mdpAdmin;
    }

    @Column( name = "statutAdmin", nullable = false, length = 20 )
    public String getStatutAdmin() {
        return this.statutAdmin;
    }

    public void setStatutAdmin( String statutAdmin ) {
        this.statutAdmin = statutAdmin;
    }

    @Column( name = "nomAdmin", nullable = false, length = 45 )
    public String getNomAdmin() {
        return this.nomAdmin;
    }

    public void setNomAdmin( String nomAdmin ) {
        this.nomAdmin = nomAdmin;
    }

    @Column( name = "prenomAdmin", nullable = false, length = 45 )
    public String getPrenomAdmin() {
        return this.prenomAdmin;
    }

    public void setPrenomAdmin( String prenomAdmin ) {
        this.prenomAdmin = prenomAdmin;
    }

}
