package com.discostore.entity;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table( name = "client", catalog = "disco" )
public class Client implements java.io.Serializable {

    private int           numCli;
    private String        nomCli;
    private String        prenomCli;
    private String        addressLine1;
    private String        addressLine2;
    private String        ville;
    private String        cp;
    private String        pays;
    private String        phone;
    private String        mail;
    private String        loginCli;
    private String        mdpCli;
    private Set<Commande> commandes = new HashSet<Commande>( 0 );

    public Client() {
    }

    public Client( int numCli, String nomCli, String prenomCli, String addressLine1, String ville, String cp,
            String pays, String phone, String loginCli, String mdpCli ) {
        this.numCli = numCli;
        this.nomCli = nomCli;
        this.prenomCli = prenomCli;
        this.addressLine1 = addressLine1;
        this.ville = ville;
        this.cp = cp;
        this.pays = pays;
        this.phone = phone;
        this.loginCli = loginCli;
        this.mdpCli = mdpCli;
    }

    public Client( int numCli, String nomCli, String prenomCli, String addressLine1, String addressLine2, String ville,
            String cp, String pays, String phone, String mail, String loginCli, String mdpCli,
            Set<Commande> commandes ) {
        this.numCli = numCli;
        this.nomCli = nomCli;
        this.prenomCli = prenomCli;
        this.addressLine1 = addressLine1;
        this.addressLine2 = addressLine2;
        this.ville = ville;
        this.cp = cp;
        this.pays = pays;
        this.phone = phone;
        this.mail = mail;
        this.loginCli = loginCli;
        this.mdpCli = mdpCli;
        this.commandes = commandes;
    }

    @Id

    @Column( name = "numCli", unique = true, nullable = false )
    public int getNumCli() {
        return this.numCli;
    }

    public void setNumCli( int numCli ) {
        this.numCli = numCli;
    }

    @Column( name = "nomCli", nullable = false, length = 50 )
    public String getNomCli() {
        return this.nomCli;
    }

    public void setNomCli( String nomCli ) {
        this.nomCli = nomCli;
    }

    @Column( name = "prenomCli", nullable = false, length = 50 )
    public String getPrenomCli() {
        return this.prenomCli;
    }

    public void setPrenomCli( String prenomCli ) {
        this.prenomCli = prenomCli;
    }

    @Column( name = "addressLine1", nullable = false, length = 50 )
    public String getAddressLine1() {
        return this.addressLine1;
    }

    public void setAddressLine1( String addressLine1 ) {
        this.addressLine1 = addressLine1;
    }

    @Column( name = "addressLine2", length = 50 )
    public String getAddressLine2() {
        return this.addressLine2;
    }

    public void setAddressLine2( String addressLine2 ) {
        this.addressLine2 = addressLine2;
    }

    @Column( name = "ville", nullable = false, length = 50 )
    public String getVille() {
        return this.ville;
    }

    public void setVille( String ville ) {
        this.ville = ville;
    }

    @Column( name = "cp", nullable = false, length = 15 )
    public String getCp() {
        return this.cp;
    }

    public void setCp( String cp ) {
        this.cp = cp;
    }

    @Column( name = "pays", nullable = false, length = 50 )
    public String getPays() {
        return this.pays;
    }

    public void setPays( String pays ) {
        this.pays = pays;
    }

    @Column( name = "phone", nullable = false, length = 50 )
    public String getPhone() {
        return this.phone;
    }

    public void setPhone( String phone ) {
        this.phone = phone;
    }

    @Column( name = "mail", length = 60 )
    public String getMail() {
        return this.mail;
    }

    public void setMail( String mail ) {
        this.mail = mail;
    }

    @Column( name = "loginCli", nullable = false, length = 60 )
    public String getLoginCli() {
        return this.loginCli;
    }

    public void setLoginCli( String loginCli ) {
        this.loginCli = loginCli;
    }

    @Column( name = "mdpCli", nullable = false, length = 60 )
    public String getMdpCli() {
        return this.mdpCli;
    }

    public void setMdpCli( String mdpCli ) {
        this.mdpCli = mdpCli;
    }

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "client" )
    public Set<Commande> getCommandes() {
        return this.commandes;
    }

    public void setCommandes( Set<Commande> commandes ) {
        this.commandes = commandes;
    }

}
