package com.discostore.entity;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table( name = "genre", catalog = "disco" )


@NamedQueries( {
    @NamedQuery(name = "Genre.findAll", query=
    "SELECT g FROM Genre g ORDER BY g.intituleGenre"),
    @NamedQuery(name = "Genre.countAll", query=
            "SELECT COUNT(*) FROM Genre g"),
    @NamedQuery(name = "Genre.findByName", query=
            "SELECT g FROM Genre g WHERE g.intituleGenre = :nom")
} )


public class Genre implements java.io.Serializable {

    private int          codGenre;
    private String       intituleGenre;
    private Set<Article> articles = new HashSet<Article>( 0 );

    public Genre() {
    }

    public Genre( String intituleGenre ) {
        
        this.intituleGenre = intituleGenre;
    }
    
    
    public Genre( int codGenre, String intituleGenre ) {
        this.codGenre = codGenre;
        this.intituleGenre = intituleGenre;
    }

    public Genre( int codGenre, String intituleGenre, Set<Article> articles ) {
        this.codGenre = codGenre;
        this.intituleGenre = intituleGenre;
        this.articles = articles;
    }

    @Id
    @GeneratedValue( strategy = IDENTITY )
    @Column( name = "codGenre", unique = true, nullable = false )
    public int getCodGenre() {
        return this.codGenre;
    }

    public void setCodGenre( int codGenre ) {
        this.codGenre = codGenre;
    }

    @Column( name = "intituleGenre", nullable = false, length = 50 )
    public String getIntituleGenre() {
        return this.intituleGenre;
    }

    public void setIntituleGenre( String intituleGenre ) {
        this.intituleGenre = intituleGenre;
    }

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "genre" )
    public Set<Article> getArticles() {
        return this.articles;
    }

    public void setArticles( Set<Article> articles ) {
        this.articles = articles;
    }

}
