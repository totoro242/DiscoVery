package com.discostore.entity;

import java.math.BigDecimal;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table( name = "ligne_commande", catalog = "disco" )
public class LigneCommande implements java.io.Serializable {

    private LigneCommandeId id;
    private Article         article;
    private Commande        commande;
    private int             qtyOrdered;
    private BigDecimal      priceByQty;

    public LigneCommande() {
    }

    public LigneCommande( LigneCommandeId id, Article article, Commande commande, int qtyOrdered,
            BigDecimal priceByQty ) {
        this.id = id;
        this.article = article;
        this.commande = commande;
        this.qtyOrdered = qtyOrdered;
        this.priceByQty = priceByQty;
    }

    @EmbeddedId

    @AttributeOverrides( {
            @AttributeOverride( name = "refCommande", column = @Column( name = "refCommande", nullable = false ) ),
            @AttributeOverride( name = "refArticle", column = @Column( name = "refArticle", nullable = false ) ) } )
    public LigneCommandeId getId() {
        return this.id;
    }

    public void setId( LigneCommandeId id ) {
        this.id = id;
    }

    @ManyToOne( fetch = FetchType.LAZY )
    @JoinColumn( name = "refArticle", nullable = false, insertable = false, updatable = false )
    public Article getArticle() {
        return this.article;
    }

    public void setArticle( Article article ) {
        this.article = article;
    }

    @ManyToOne( fetch = FetchType.LAZY )
    @JoinColumn( name = "refCommande", nullable = false, insertable = false, updatable = false )
    public Commande getCommande() {
        return this.commande;
    }

    public void setCommande( Commande commande ) {
        this.commande = commande;
    }

    @Column( name = "qtyOrdered", nullable = false )
    public int getQtyOrdered() {
        return this.qtyOrdered;
    }

    public void setQtyOrdered( int qtyOrdered ) {
        this.qtyOrdered = qtyOrdered;
    }

    @Column( name = "priceByQty", nullable = false, precision = 5 )
    public BigDecimal getPriceByQty() {
        return this.priceByQty;
    }

    public void setPriceByQty( BigDecimal priceByQty ) {
        this.priceByQty = priceByQty;
    }

}
