package com.discostore.entity;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table( name = "commande", catalog = "disco" )
public class Commande implements java.io.Serializable {

    private int                refCommande;
    private Client             client;
    private Date               dateCommande;
    private Date               dateEnvoi;
    private BigDecimal         montantCommande;
    private String             adresseLivraison;
    private String             numAutorisationCb;
    private String             etat;
    private Set<LigneCommande> ligneCommandes = new HashSet<LigneCommande>( 0 );

    public Commande() {
    }

    public Commande( int refCommande, Client client, BigDecimal montantCommande, String numAutorisationCb,
            String etat ) {
        this.refCommande = refCommande;
        this.client = client;
        this.montantCommande = montantCommande;
        this.numAutorisationCb = numAutorisationCb;
        this.etat = etat;
    }

    public Commande( int refCommande, Client client, Date dateCommande, Date dateEnvoi, BigDecimal montantCommande,
            String adresseLivraison, String numAutorisationCb, String etat, Set<LigneCommande> ligneCommandes ) {
        this.refCommande = refCommande;
        this.client = client;
        this.dateCommande = dateCommande;
        this.dateEnvoi = dateEnvoi;
        this.montantCommande = montantCommande;
        this.adresseLivraison = adresseLivraison;
        this.numAutorisationCb = numAutorisationCb;
        this.etat = etat;
        this.ligneCommandes = ligneCommandes;
    }

    @Id

    @Column( name = "refCommande", unique = true, nullable = false )
    public int getRefCommande() {
        return this.refCommande;
    }

    public void setRefCommande( int refCommande ) {
        this.refCommande = refCommande;
    }

    @ManyToOne( fetch = FetchType.LAZY )
    @JoinColumn( name = "numCli", nullable = false )
    public Client getClient() {
        return this.client;
    }

    public void setClient( Client client ) {
        this.client = client;
    }

    @Temporal( TemporalType.TIMESTAMP )
    @Column( name = "dateCommande", length = 19 )
    public Date getDateCommande() {
        return this.dateCommande;
    }

    public void setDateCommande( Date dateCommande ) {
        this.dateCommande = dateCommande;
    }

    @Temporal( TemporalType.TIMESTAMP )
    @Column( name = "dateEnvoi", length = 19 )
    public Date getDateEnvoi() {
        return this.dateEnvoi;
    }

    public void setDateEnvoi( Date dateEnvoi ) {
        this.dateEnvoi = dateEnvoi;
    }

    @Column( name = "montantCommande", nullable = false, precision = 5 )
    public BigDecimal getMontantCommande() {
        return this.montantCommande;
    }

    public void setMontantCommande( BigDecimal montantCommande ) {
        this.montantCommande = montantCommande;
    }

    @Column( name = "adresseLivraison", length = 200 )
    public String getAdresseLivraison() {
        return this.adresseLivraison;
    }

    public void setAdresseLivraison( String adresseLivraison ) {
        this.adresseLivraison = adresseLivraison;
    }

    @Column( name = "numAutorisationCB", nullable = false, length = 250 )
    public String getNumAutorisationCb() {
        return this.numAutorisationCb;
    }

    public void setNumAutorisationCb( String numAutorisationCb ) {
        this.numAutorisationCb = numAutorisationCb;
    }

    @Column( name = "etat", nullable = false, length = 30 )
    public String getEtat() {
        return this.etat;
    }

    public void setEtat( String etat ) {
        this.etat = etat;
    }

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "commande" )
    public Set<LigneCommande> getLigneCommandes() {
        return this.ligneCommandes;
    }

    public void setLigneCommandes( Set<LigneCommande> ligneCommandes ) {
        this.ligneCommandes = ligneCommandes;
    }

}
