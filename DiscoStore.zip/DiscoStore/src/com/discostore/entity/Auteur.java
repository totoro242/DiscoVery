package com.discostore.entity;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table( name = "auteur", catalog = "disco" )

@NamedQueries( {   
    @NamedQuery(name = "Auteur.findAll", query=
            "SELECT a FROM Auteur a ORDER BY a.nomAuteur"),   
    @NamedQuery(name = "Auteur.findByName", query=
            "SELECT a FROM Auteur a WHERE a.nomAuteur = :nom")
} )
public class Auteur implements java.io.Serializable {

    private Integer      codAuteur;
    private String       nomAuteur;
    private String       qualite;
    private String       bio;
    private Set<Article> articles = new HashSet<Article>( 0 );

    public Auteur() {
    }

    public Auteur( String nomAuteur ) {
        this.nomAuteur = nomAuteur;
    }

    public Auteur( String nomAuteur, String qualite, String bio, Set<Article> articles ) {
        this.nomAuteur = nomAuteur;
        this.qualite = qualite;
        this.bio = bio;
        this.articles = articles;
    }

    @Id
    @GeneratedValue( strategy = IDENTITY )

    @Column( name = "codAuteur", unique = true, nullable = false )
    public Integer getCodAuteur() {
        return this.codAuteur;
    }

    public void setCodAuteur( Integer codAuteur ) {
        this.codAuteur = codAuteur;
    }

    @Column( name = "nomAuteur", nullable = false, length = 200 )
    public String getNomAuteur() {
        return this.nomAuteur;
    }

    public void setNomAuteur( String nomAuteur ) {
        this.nomAuteur = nomAuteur;
    }

    @Column( name = "qualite", length = 50 )
    public String getQualite() {
        return this.qualite;
    }

    public void setQualite( String qualite ) {
        this.qualite = qualite;
    }

    @Column( name = "bio", length = 65535 )
    public String getBio() {
        return this.bio;
    }

    public void setBio( String bio ) {
        this.bio = bio;
    }

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "auteur" )
    public Set<Article> getArticles() {
        return this.articles;
    }

    public void setArticles( Set<Article> articles ) {
        this.articles = articles;
    }

}
